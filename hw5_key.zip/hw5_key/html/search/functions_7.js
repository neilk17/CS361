var searchData=
[
  ['startmessage_0',['startMessage',['../main_8cpp.html#abbce6e8be2e0d887ce9e01542db81dd7',1,'main.cpp']]],
  ['stopmessage_1',['stopMessage',['../main_8cpp.html#ae908b39f5fc9ea789d0bfea25a63b7fb',1,'main.cpp']]]
];
