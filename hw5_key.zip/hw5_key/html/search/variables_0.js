var searchData=
[
  ['current_0',['current',['../class_leader_board.html#a513623ab13a9b44b9945a656c0e8996a',1,'LeaderBoard']]]
];
