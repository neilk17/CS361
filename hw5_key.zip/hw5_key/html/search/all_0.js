var searchData=
[
  ['adddice_0',['addDice',['../class_dice_queue.html#a22043d79892d47da7b047cd5584837e9',1,'DiceQueue']]],
  ['addracer_1',['addRacer',['../class_leader_board.html#a0d496bf804283c8d91379667f395e7fb',1,'LeaderBoard']]]
];
