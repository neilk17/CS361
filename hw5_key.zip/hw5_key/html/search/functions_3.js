var searchData=
[
  ['gamemaster_0',['gameMaster',['../main_8cpp.html#a5860ff1493dd3e21ef57f59acfb26bd2',1,'main.cpp']]],
  ['getdice_1',['getDice',['../class_dice_queue.html#a4c80e2d04e599fb97b76b46aaab1dfc5',1,'DiceQueue']]],
  ['getplace_2',['getPlace',['../class_leader_board.html#aa53f0751cb5064c69cbd6017103b3481',1,'LeaderBoard']]]
];
