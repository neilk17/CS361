var searchData=
[
  ['racers_0',['racers',['../class_leader_board.html#a579f7863d33534648b91d13e5a4efab9',1,'LeaderBoard']]],
  ['results_1',['results',['../class_leader_board.html#a9f61db0d3e45ba9e0a23bd760ad9365c',1,'LeaderBoard']]]
];
